package com.example.imadstatistics

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    private val numbers = mutableListOf<Int>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //Advtech online.(n.d.).Portfolio of Evidence- Basic Statistics Calculations [Online PDF].
        //Available at: [https://advtechonline.sharepoint.com/sites/TertiaryStudents/IIE%20Student%20Materials/Forms/Default%20View.aspx?id=%2Fsites%2FTertiaryStudents%2FIIE%20Student%20Materials%2FNew%20Student%20Materials%20CAT%2FIMAD5112%2F2023%2FIMAD5112POE%2Epdf&parent=%2Fsites%2FTertiaryStudents%2FIIE%20Student%20Materials%2FNew%20Student%20Materials%20CAT%2FIMAD5112%2F2023]
        //(Accessed: [02 November 2023])

        val numberEditText = findViewById<EditText>(R.id.editTextNumberDecimal)
        val addButton = findViewById<Button>(R.id.button)
        val clearButton = findViewById<Button>(R.id.button2)
        val averageButton = findViewById<Button>(R.id.button3)
        val minMaxButton = findViewById<Button>(R.id.button4)
        val answerTextView = findViewById<TextView>(R.id.editTextText2)

        addButton.setOnClickListener {
            val number = numberEditText.text.toString().toIntOrNull()
            if (number != null && numbers.size < 10 ) {
                numbers.add(number)
                displayNumbers()
                numberEditText.text.clear()
            } else {
                Toast.makeText(this,"Maximum number of integers reached", Toast.LENGTH_SHORT).show()
            }
        }

        clearButton.setOnClickListener {
            numbers.clear()
            displayNumbers()
            answerTextView.text = ""
        }

        averageButton.setOnClickListener {
            if (numbers.isEmpty()) {
                answerTextView.text = ""
            } else {
                val average = numbers.average()
                answerTextView.text = "The average is $average "
            }
        }
        minMaxButton.setOnClickListener {
            if (numbers.isEmpty()) {
                answerTextView.text =""
            } else {
                val minimum = numbers.minOrNull()
                val maximum = numbers.maxOrNull()
                answerTextView.text = "Minimum: $minimum\nMaximum: $maximum"
            }
        }
    }
    private fun displayNumbers() {
        val numbersTextView = findViewById<EditText>(R.id.editTextText)
        val numbersText = numbers.joinToString(",")
        numbersTextView.setText(numbersText)
    }
}